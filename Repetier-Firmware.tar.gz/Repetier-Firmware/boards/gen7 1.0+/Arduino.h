#include "WProgram.h"
#define COMPAT_PRE1
