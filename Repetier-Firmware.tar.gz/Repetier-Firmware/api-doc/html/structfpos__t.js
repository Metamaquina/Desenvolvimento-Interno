var structfpos__t =
[
    [ "fpos_t", "structfpos__t.html#a8558a88fc56402fc3833a0d410669d1f", null ],
    [ "cluster", "structfpos__t.html#a5cc194a79520802c25787f3072f8fe5b", null ],
    [ "position", "structfpos__t.html#ac66edcab862b65e1d49ce97f9c74690c", null ]
];