var struct_temperature_controller =
[
    [ "currentTemperature", "struct_temperature_controller.html#a312344cfcf54842935c4df4d67d24154", null ],
    [ "currentTemperatureC", "struct_temperature_controller.html#aaef2b12184c93d3d1e810e16b0622d70", null ],
    [ "heatManager", "struct_temperature_controller.html#ab7cf8def273bbe793b894087bc80ee5f", null ],
    [ "lastTemperatureUpdate", "struct_temperature_controller.html#aae9dbd112d23b40ee5f573e91a0e40ff", null ],
    [ "pidDGain", "struct_temperature_controller.html#a7146e3620b552f2e1933bada1dfc1157", null ],
    [ "pidDriveMax", "struct_temperature_controller.html#affe50befa6c77b58aecdf130a62b900a", null ],
    [ "pidDriveMin", "struct_temperature_controller.html#a04769ade1512e28f371e3c5bd9eb550f", null ],
    [ "pidIGain", "struct_temperature_controller.html#a088ae08937ece0b330031cc79f2ddd41", null ],
    [ "pidMax", "struct_temperature_controller.html#a4fd91b11a179cc44ad4e984143f33a94", null ],
    [ "pidPGain", "struct_temperature_controller.html#a59542e4cc766a6c11e07270d5245bfea", null ],
    [ "pwmIndex", "struct_temperature_controller.html#ac7ea110f24b180767e043e276dc21e90", null ],
    [ "sensorPin", "struct_temperature_controller.html#a79cafd445a67566e2713485ed87c1439", null ],
    [ "sensorType", "struct_temperature_controller.html#a3a5254ba393ca36615e9709981240ceb", null ],
    [ "targetTemperature", "struct_temperature_controller.html#a7dc7e4c0189d36e4d5c4e4aa41cec731", null ],
    [ "targetTemperatureC", "struct_temperature_controller.html#aa74b6e6ce4377461c89007835536d846", null ],
    [ "tempArray", "struct_temperature_controller.html#abbb5a6235e2715f2041319a467856f6d", null ],
    [ "tempIState", "struct_temperature_controller.html#a473cb0357a6e307081c09d62715507cf", null ],
    [ "tempIStateLimitMax", "struct_temperature_controller.html#a1c7d2c920a501e240e7cc3b3b6054ff4", null ],
    [ "tempIStateLimitMin", "struct_temperature_controller.html#a5b28147bc0ae29c5884be12d6128423b", null ],
    [ "tempPointer", "struct_temperature_controller.html#ae5a1b2708902480b80856dad81e08b43", null ]
];