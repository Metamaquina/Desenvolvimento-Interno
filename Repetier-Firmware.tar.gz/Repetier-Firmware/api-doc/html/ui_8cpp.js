var ui_8cpp =
[
    [ "UI_MAIN", "ui_8cpp.html#a18b97b32e277e5cc9178cf4d56f62b1d", null ],
    [ "beep", "ui_8cpp.html#a0ee488dbf276ee9f31b7bae8c902ad27", null ],
    [ "PROGMEM", "ui_8cpp.html#a0ecb7d204e04196a839885837c052002", null ],
    [ "ui_autoreturn_time", "ui_8cpp.html#ab0a52fa48d1f24b6cd4d3a439067e178", null ]
];