var structfat32__fsinfo =
[
    [ "freeCount", "structfat32__fsinfo.html#af5d9e0aff08147617a09dc19d207eafe", null ],
    [ "leadSignature", "structfat32__fsinfo.html#a19196eeae2525130bdb0d39607860743", null ],
    [ "nextFree", "structfat32__fsinfo.html#a456cdbc01678df5d05eabb80f5aac9b0", null ],
    [ "reserved1", "structfat32__fsinfo.html#aed41fe36034f1fcda738da60943924a6", null ],
    [ "reserved2", "structfat32__fsinfo.html#af6dc8e21f5c1ca5ca997fc835808802c", null ],
    [ "structSignature", "structfat32__fsinfo.html#a31ea8ae6a8d32f61dd576d0d4921f015", null ],
    [ "tailSignature", "structfat32__fsinfo.html#a89944902cc4effcd8568575786c3a084", null ]
];