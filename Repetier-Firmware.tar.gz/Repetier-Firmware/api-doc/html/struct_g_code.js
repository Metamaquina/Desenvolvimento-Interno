var struct_g_code =
[
    [ "E", "struct_g_code.html#a5b514bbfa4713e7bcf9c6a367cb6ebfe", null ],
    [ "F", "struct_g_code.html#a9ab4bd02302051f763e80ede43fcac71", null ],
    [ "G", "struct_g_code.html#a8f7aab5ea8436167078632d62232a98a", null ],
    [ "I", "struct_g_code.html#a145f61de888f096c52a2945234a407b0", null ],
    [ "J", "struct_g_code.html#a7c20f6b5c2b8c830d450944735b761b3", null ],
    [ "M", "struct_g_code.html#a68dc0bf731afd0463b8e8cc4ed81c0f8", null ],
    [ "N", "struct_g_code.html#ae8b170dcb376fe60270f4675f84e4477", null ],
    [ "P", "struct_g_code.html#ad510039b7e7f97aaedeeda277b423624", null ],
    [ "params", "struct_g_code.html#a9575eb2cccc85ee4d0800ceca524e220", null ],
    [ "params2", "struct_g_code.html#acfbeb6013604a585552007021f3236ba", null ],
    [ "R", "struct_g_code.html#a4c4b08e61e92b3da1ed512f4e006f34a", null ],
    [ "S", "struct_g_code.html#a531ffbc18075585b12607aff08fec9b0", null ],
    [ "T", "struct_g_code.html#a56d2adf7837705583cba96a42b0b6b60", null ],
    [ "text", "struct_g_code.html#a5633b1433389cec21ade3811bbe9ca5b", null ],
    [ "X", "struct_g_code.html#ab3c4b737dfc5c78a6aba50dda616f7c3", null ],
    [ "Y", "struct_g_code.html#ac915220fb659eb2c5958a1ccd81b80d4", null ],
    [ "Z", "struct_g_code.html#aa65967cca170d24dcd0d555df0d5ee4f", null ]
];