var structbios_parm_block =
[
    [ "bytesPerSector", "structbios_parm_block.html#adb2ddeae74baf681103d21d724814a63", null ],
    [ "fat32BackBootBlock", "structbios_parm_block.html#a1914baf34756efd18072059dccfcf40f", null ],
    [ "fat32Flags", "structbios_parm_block.html#a4f864cefb7f1b004d5739ffab9a65ae1", null ],
    [ "fat32FSInfo", "structbios_parm_block.html#aad3222ea255af06d09734e96a93c82ed", null ],
    [ "fat32Reserved", "structbios_parm_block.html#ae31dc7ad96aec8e0d184fd7e5a97f30d", null ],
    [ "fat32RootCluster", "structbios_parm_block.html#a58249ed4ed0f92d5768f2342f248af82", null ],
    [ "fat32Version", "structbios_parm_block.html#a8f27235fa3dee48a4b4e099135fc81d6", null ],
    [ "fatCount", "structbios_parm_block.html#a624e9eb125b4fc8aeaebcccf79e17aa8", null ],
    [ "headCount", "structbios_parm_block.html#a57cb7e16b9969fa87c9f1ca43a87d217", null ],
    [ "hidddenSectors", "structbios_parm_block.html#a454fd6cc3f063c86b7fe65c367da7cdd", null ],
    [ "mediaType", "structbios_parm_block.html#ab88738f9cb91c882cb91d5e83a19a73f", null ],
    [ "reservedSectorCount", "structbios_parm_block.html#a16c854faf567331bbbfb383e6c8df6f5", null ],
    [ "rootDirEntryCount", "structbios_parm_block.html#aabe25e54b9c06a9a7393fc6c475d9fa1", null ],
    [ "sectorsPerCluster", "structbios_parm_block.html#a3ce07376c286acd8393a18a32d7ca4c0", null ],
    [ "sectorsPerFat16", "structbios_parm_block.html#abf85d1c57b01c8901a0cdcd0ac1babc2", null ],
    [ "sectorsPerFat32", "structbios_parm_block.html#a687653b3b71ab0de1f27f8ab8f331a1c", null ],
    [ "sectorsPerTrtack", "structbios_parm_block.html#ae1928fd953f5d0f198826c93c320f2b2", null ],
    [ "totalSectors16", "structbios_parm_block.html#ad717f5b9af13f8ec9d0d6d1337174dfa", null ],
    [ "totalSectors32", "structbios_parm_block.html#a64d5902f9e900ecc745b1c0b325d875f", null ]
];