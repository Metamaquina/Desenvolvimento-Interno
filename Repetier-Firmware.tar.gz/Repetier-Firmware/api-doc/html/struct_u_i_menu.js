var struct_u_i_menu =
[
    [ "entries", "struct_u_i_menu.html#a22d5a03ad6075b65e955196937e7f6ad", null ],
    [ "id", "struct_u_i_menu.html#a7441ef0865bcb3db9b8064dd7375c1ea", null ],
    [ "menuType", "struct_u_i_menu.html#abe780536c31ff5db0168630df52b840a", null ],
    [ "numEntries", "struct_u_i_menu.html#a75b15f0e26b4ccf3195772b134b660ec", null ]
];