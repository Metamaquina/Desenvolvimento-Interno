var structfat32_boot_sector =
[
    [ "bootCode", "structfat32_boot_sector.html#a5d683c906867f4e0122d2ce3462de292", null ],
    [ "bootSectorSig0", "structfat32_boot_sector.html#abdaf2cc75b74800944ede557442ca5bd", null ],
    [ "bootSectorSig1", "structfat32_boot_sector.html#a44983e94ecddbdcb7ab691e493a13d94", null ],
    [ "bootSignature", "structfat32_boot_sector.html#acc4a4e4c22b630d12c1b2c2b8c7eb366", null ],
    [ "bpb", "structfat32_boot_sector.html#a4d8105e4754b2750ab421b9e84d2c43e", null ],
    [ "driveNumber", "structfat32_boot_sector.html#aa7c65fdb4f759fca094105d1c870bcb2", null ],
    [ "fileSystemType", "structfat32_boot_sector.html#adf80bb044ef7c8ac6d371268aa338e23", null ],
    [ "jmpToBootCode", "structfat32_boot_sector.html#ae765fe8abf71fd961317f4314e16c1ac", null ],
    [ "oemName", "structfat32_boot_sector.html#ac1adff84818e7f18fdfea3374569a380", null ],
    [ "reserved1", "structfat32_boot_sector.html#a2a2556147677ece60b8aadf4a0d608ed", null ],
    [ "volumeLabel", "structfat32_boot_sector.html#a253960050a38d2bfb2f57e86769aca62", null ],
    [ "volumeSerialNumber", "structfat32_boot_sector.html#a7c9ffcee12051cefe1724e8024af25f8", null ]
];