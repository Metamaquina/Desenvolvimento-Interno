var searchData=
[
  ['cid_5ft',['cid_t',['../_sd_fat_8h.html#a7f1c4653597f0e5276671139a3592dcd',1,'SdFat.h']]],
  ['csd1_5ft',['csd1_t',['../_sd_fat_8h.html#a4dc5a2aea3d7715c82094bce06e1b3a7',1,'SdFat.h']]],
  ['csd2_5ft',['csd2_t',['../_sd_fat_8h.html#a3e07997926302b26d47ffb0535da9d01',1,'SdFat.h']]]
];
