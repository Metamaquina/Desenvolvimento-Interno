var searchData=
[
  ['part_5ft',['part_t',['../_fat_structs_8h.html#a37251e7d5c69a159be727a3fc8c9d0e6',1,'part_t():&#160;FatStructs.h'],['../_sd_fat_8h.html#a37251e7d5c69a159be727a3fc8c9d0e6',1,'part_t():&#160;SdFat.h']]]
];
