var searchData=
[
  ['_7esdbasefile',['~SdBaseFile',['../class_sd_base_file.html#a82c164ca83dc69f7551324a027ffe89e',1,'SdBaseFile']]]
];
