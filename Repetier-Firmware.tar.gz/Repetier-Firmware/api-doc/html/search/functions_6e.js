var searchData=
[
  ['nextpreviousaction',['nextPreviousAction',['../class_u_i_display.html#a0b636118b460a143ed5501b220570d93',1,'UIDisplay']]]
];
