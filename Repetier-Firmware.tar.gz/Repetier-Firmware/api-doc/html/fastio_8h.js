var fastio_8h =
[
    [ "_GET_INPUT", "fastio_8h.html#a81799334b3ecca1e9822f2c5e0c808ff", null ],
    [ "_GET_OUTPUT", "fastio_8h.html#a145970250cd701164115c116682ddcd4", null ],
    [ "_READ", "fastio_8h.html#a716f4ca15267c9a5d479514a1de83018", null ],
    [ "_SET_INPUT", "fastio_8h.html#ab76d0856bcf266de49269a05b96fb79b", null ],
    [ "_SET_OUTPUT", "fastio_8h.html#affb369f6db19ae9eab9a4c440b19c6d0", null ],
    [ "_TOGGLE", "fastio_8h.html#ac80afd6e46adcab936eb01031e25043c", null ],
    [ "_WRITE", "fastio_8h.html#acb82a1ce7f87b692abfb5e41d6810f2b", null ],
    [ "GET_INPUT", "fastio_8h.html#a8239afa0238afc5ccad6202f14dde224", null ],
    [ "GET_OUTPUT", "fastio_8h.html#af2d22ed088f7f41f71de346dbeae57fc", null ],
    [ "READ", "fastio_8h.html#a9716cca366b99de7c0d101eeab24c967", null ],
    [ "SET_INPUT", "fastio_8h.html#afa76df25ccdb2d113a057c8c305399cc", null ],
    [ "SET_OUTPUT", "fastio_8h.html#a4bdb8759f0e85e88956ac23262e0916b", null ],
    [ "TOGGLE", "fastio_8h.html#af060bb41ede214a91d237e63f3e080d4", null ],
    [ "WRITE", "fastio_8h.html#a3d38c0667426652d3fa2eb62f23e1591", null ]
];